#!/usr/bin/env python3
"""
generate_logs.py — create a representative test log file for the Log Analyzer.

Usage:
    python scripts/generate_logs.py [--lines N] [--out PATH]

Generates a mix of:
  - Standard log lines
  - Lines with alternative timestamp formats
  - Lines with response time in seconds
  - Lines with missing status codes
  - Lines with extra fields (user-agent, referrer)
  - Entirely malformed lines and blank lines
  - Multi-line stack traces interrupting the flow
  - JSON-formatted log lines (second log format)
"""

import random
import json
import argparse
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
PATHS = [
    '/api/users', '/api/users/{id}', '/api/login', '/api/logout',
    '/api/products', '/api/products/{id}', '/api/orders', '/api/orders/{id}',
    '/api/search', '/api/health', '/static/css/app.css', '/static/js/bundle.js',
    '/admin/dashboard', '/admin/users', '/metrics',
]
STATUS_CODES = [200] * 60 + [201] * 10 + [301] * 5 + [400] * 8 + [401] * 5 + \
               [403] * 3 + [404] * 10 + [500] * 5 + [503] * 2 + [429] * 2

IPS = [
    '192.168.1.' + str(i) for i in range(1, 20)
] + [
    '10.0.0.' + str(i) for i in range(1, 10)
] + ['172.16.0.5', '203.0.113.42', '198.51.100.7']

USER_AGENTS = [
    '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"',
    '"curl/7.68.0"',
    '"python-requests/2.28.2"',
    '"Googlebot/2.1 (+http://www.google.com/bot.html)"',
]

MALFORMED_LINES = [
    '',
    '   ',
    'java.lang.NullPointerException: null',
    '\tat com.example.service.UserService.getUser(UserService.java:42)',
    '\tat com.example.api.UserController.handleRequest(UserController.java:88)',
    '------- request dump -------',
    'WARN  [pool-1-thread-3] Request processing error',
    '!!CORRUPTED!! \x00\x01\x02 partial write',
    '2024-03-15T garbage data that never finishes',
    'GET /lost-my-ip 200 50ms',  # missing IP
]


def random_path():
    p = random.choice(PATHS)
    if '{id}' in p:
        p = p.replace('{id}', str(random.randint(1, 9999)))
    return p


def iso_timestamp(dt):
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


def slash_timestamp(dt):
    return dt.strftime('%Y/%m/%d %H:%M:%S')


def day_mon_year_timestamp(dt):
    return dt.strftime('%d-%b-%Y %H:%M:%S')


def unix_epoch(dt):
    return str(int(dt.timestamp()))


def format_rt(ms):
    choice = random.random()
    if choice < 0.75:
        return f'{ms}ms'
    elif choice < 0.90:
        return f'{ms / 1000:.3f}s'
    else:
        return str(ms)


def standard_line(dt, ip, method, path, status, rt_ms, extra=False):
    ts = iso_timestamp(dt)
    status_str = str(status) if random.random() > 0.02 else '-'
    rt_str = format_rt(rt_ms)
    line = f'{ts} {ip} {method} {path} {status_str} {rt_str}'
    if extra:
        line += ' ' + random.choice(USER_AGENTS)
        if random.random() < 0.3:
            line += ' "https://referrer.example.com/page"'
    return line


def alt_timestamp_line(dt, ip, method, path, status, rt_ms):
    fmt = random.choice([slash_timestamp, day_mon_year_timestamp, unix_epoch])
    ts = fmt(dt)
    return f'{ts} {ip} {method} {path} {status} {format_rt(rt_ms)}'


def json_line(dt, ip, method, path, status, rt_ms):
    obj = {
        'timestamp': iso_timestamp(dt),
        'ip': ip,
        'method': method,
        'path': path,
        'status': status,
        'response_time': f'{rt_ms}ms',
        'level': 'INFO',
    }
    return json.dumps(obj)


def generate(n_lines, seed=42):
    random.seed(seed)
    base_time = datetime(2024, 3, 15, 0, 0, 0, tzinfo=timezone.utc)
    lines = []
    i = 0
    while i < n_lines:
        dt = base_time + timedelta(seconds=i * random.uniform(0.5, 3))
        ip = random.choice(IPS)
        method = random.choice(METHODS)
        path = random_path()
        status = random.choice(STATUS_CODES)
        rt_ms = max(1, int(random.lognormvariate(4.5, 1.2)))  # realistic skewed latency

        roll = random.random()

        if roll < 0.005:
            # Inject a multi-line stack trace (3 lines)
            lines.append(MALFORMED_LINES[2])
            lines.append(MALFORMED_LINES[3])
            lines.append(MALFORMED_LINES[4])
            i += 3
        elif roll < 0.02:
            # Random malformed line
            lines.append(random.choice(MALFORMED_LINES))
            i += 1
        elif roll < 0.04:
            # Blank line
            lines.append('')
            i += 1
        elif roll < 0.08:
            # JSON-format line
            lines.append(json_line(dt, ip, method, path, status, rt_ms))
            i += 1
        elif roll < 0.13:
            # Alt timestamp format
            lines.append(alt_timestamp_line(dt, ip, method, path, status, rt_ms))
            i += 1
        elif roll < 0.20:
            # Extra fields
            lines.append(standard_line(dt, ip, method, path, status, rt_ms, extra=True))
            i += 1
        else:
            lines.append(standard_line(dt, ip, method, path, status, rt_ms))
            i += 1

    return lines


def main():
    parser = argparse.ArgumentParser(description='Generate a test log file.')
    parser.add_argument('--lines', type=int, default=5000, help='Approximate number of lines (default 5000)')
    parser.add_argument('--out', default='test.log', help='Output file path (default test.log)')
    args = parser.parse_args()

    lines = generate(args.lines)
    out = Path(args.out)
    out.write_text('\n'.join(lines) + '\n')
    print(f'Generated {len(lines)} lines -> {out}')


if __name__ == '__main__':
    main()
