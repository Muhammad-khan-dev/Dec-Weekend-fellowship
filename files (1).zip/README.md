# Log Analyzer

A command-line tool that ingests messy web-server log files and produces a
human-readable summary report. It handles multiple timestamp formats, response-time
units, missing status codes, extra fields, JSON-formatted lines, stack traces, and
other real-world deviations — degrading gracefully when lines cannot be parsed.

---

## Requirements

- Python 3.8 or higher (no third-party packages required — stdlib only)

---

## How to Run

### 1 — Generate a test log file

```bash
python scripts/generate_logs.py --lines 5000 --out test.log
```

Options:
| Flag | Default | Description |
|------|---------|-------------|
| `--lines N` | 5000 | Approximate number of lines to generate |
| `--out PATH` | `test.log` | Output file path |

### 2 — Run the analyzer

```bash
python analyzer.py test.log
```

Options:
| Flag | Description |
|------|-------------|
| `--top N` | Show top-N entries in each section (default 10) |
| `--json` | Output raw JSON instead of the text report |

### Examples

```bash
# Analyse a file, show top 5 in each section
python analyzer.py /var/log/web/access.log --top 5

# Machine-readable JSON output
python analyzer.py test.log --json

# Pipe to a pager
python analyzer.py test.log | less
```

---

## Output

The text report includes:

- **Ingestion stats** — total lines, parsed, skipped, skip reasons, soft warnings
- **HTTP status breakdown** — counts per status code with labels
- **HTTP method breakdown**
- **Top N slowest endpoints** — ranked by average response time (ms)
- **Top N error-prone paths** — 4xx/5xx hit count per path
- **Top N most active IPs**
- **Traffic by hour** — ASCII bar chart of request volume

---

## Project Layout

```
log_analyzer/
├── analyzer.py          # Main analysis tool
├── scripts/
│   └── generate_logs.py # Test data generator
├── tests/
│   └── test_parser.py   # Unit tests (stdlib unittest)
├── README.md
└── ANSWERS.md
```

---

## Running Tests

```bash
python -m pytest tests/ -v
# or without pytest:
python -m unittest discover tests/
```
