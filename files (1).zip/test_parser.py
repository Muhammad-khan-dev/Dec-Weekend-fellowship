#!/usr/bin/env python3
"""
Unit tests for the log analyzer parser.
Run with:  python -m unittest discover tests/
       or: python -m pytest tests/ -v
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from analyzer import parse_timestamp, parse_response_time, parse_line


class TestParseTimestamp(unittest.TestCase):

    def test_iso8601_z(self):
        ts = parse_timestamp('2024-03-15T14:23:01Z')
        self.assertIsNotNone(ts)
        self.assertEqual(ts.year, 2024)
        self.assertEqual(ts.hour, 14)

    def test_slash_format(self):
        ts = parse_timestamp('2024/03/15 14:23:01')
        self.assertIsNotNone(ts)
        self.assertEqual(ts.day, 15)

    def test_day_mon_year(self):
        ts = parse_timestamp('15-Mar-2024 14:23:01')
        self.assertIsNotNone(ts)
        self.assertEqual(ts.month, 3)

    def test_unix_epoch(self):
        ts = parse_timestamp('1710512581')
        self.assertIsNotNone(ts)
        self.assertEqual(ts.year, 2024)

    def test_garbage_returns_none(self):
        ts = parse_timestamp('not-a-date')
        self.assertIsNone(ts)


class TestParseResponseTime(unittest.TestCase):

    def test_ms_suffix(self):
        self.assertAlmostEqual(parse_response_time('142ms'), 142.0)

    def test_s_suffix(self):
        self.assertAlmostEqual(parse_response_time('0.142s'), 142.0)

    def test_bare_number(self):
        self.assertAlmostEqual(parse_response_time('142'), 142.0)

    def test_zero_is_not_none(self):
        # Edge case: 0ms is valid, must not be dropped by falsy check
        result = parse_response_time('0ms')
        self.assertIsNotNone(result)
        self.assertEqual(result, 0.0)

    def test_garbage_returns_none(self):
        self.assertIsNone(parse_response_time('fast'))


class TestParseLine(unittest.TestCase):

    def _good_line(self):
        return '2024-03-15T14:23:01Z 192.168.1.42 GET /api/users 200 142ms'

    def test_standard_line_parses(self):
        rec, reason = parse_line(self._good_line())
        self.assertIsNotNone(rec)
        self.assertIsNone(reason)
        self.assertEqual(rec['method'], 'GET')
        self.assertEqual(rec['status'], 200)
        self.assertAlmostEqual(rec['response_time_ms'], 142.0)

    def test_blank_line_skipped(self):
        rec, reason = parse_line('')
        self.assertIsNone(rec)
        self.assertEqual(reason, 'blank')

    def test_missing_status_warns(self):
        line = '2024-03-15T14:23:01Z 192.168.1.42 GET /api/users - 142ms'
        rec, reason = parse_line(line)
        self.assertIsNotNone(rec)
        self.assertIsNone(rec['status'])
        self.assertIn('missing_status', rec['warnings'])

    def test_json_line_parses(self):
        import json
        obj = {'timestamp': '2024-03-15T14:23:01Z', 'ip': '10.0.0.1',
               'method': 'POST', 'path': '/api/login', 'status': 401,
               'response_time': '89ms'}
        rec, reason = parse_line(json.dumps(obj))
        self.assertIsNotNone(rec)
        self.assertEqual(rec['format'], 'json')
        self.assertEqual(rec['status'], 401)

    def test_malformed_line_skipped(self):
        rec, reason = parse_line('java.lang.NullPointerException: null')
        self.assertIsNone(rec)
        self.assertEqual(reason, 'malformed')

    def test_extra_fields_ignored(self):
        line = '2024-03-15T14:23:01Z 192.168.1.42 GET /api/users 200 142ms "Mozilla/5.0"'
        rec, reason = parse_line(line)
        self.assertIsNotNone(rec)  # extra field should not break parsing

    def test_alt_timestamp_slash(self):
        line = '2024/03/15 14:23:01 192.168.1.5 GET /api/health 200 10ms'
        rec, reason = parse_line(line)
        self.assertIsNotNone(rec)

    def test_response_time_in_seconds(self):
        line = '2024-03-15T14:23:01Z 10.0.0.1 GET /slow 200 0.500s'
        rec, reason = parse_line(line)
        self.assertIsNotNone(rec)
        self.assertAlmostEqual(rec['response_time_ms'], 500.0)


if __name__ == '__main__':
    unittest.main()
