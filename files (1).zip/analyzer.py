#!/usr/bin/env python3
"""
Log Analyzer — parses messy web-server log files and produces a human-readable
summary report (error patterns, slowest endpoints, IP activity, format anomalies).

Usage:
    python analyzer.py <path-to-log-file> [--json] [--top N]
"""

import sys
import re
import json
import argparse
from datetime import datetime, timezone
from collections import defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# Timestamp normalisation
# ---------------------------------------------------------------------------

_TS_PATTERNS = [
    # ISO 8601 with Z or offset  2024-03-15T14:23:01Z
    (re.compile(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:Z|[+-]\d{2}:\d{2})?'),
     lambda m: datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)),
    # Slash date  2024/03/15 14:23:01
    (re.compile(r'(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})'),
     lambda m: datetime.strptime(m.group(1), "%Y/%m/%d %H:%M:%S").replace(tzinfo=timezone.utc)),
    # Day-Mon-Year  15-Mar-2024 14:23:01
    (re.compile(r'(\d{1,2}-[A-Za-z]{3}-\d{4} \d{2}:\d{2}:\d{2})'),
     lambda m: datetime.strptime(m.group(1), "%d-%b-%Y %H:%M:%S").replace(tzinfo=timezone.utc)),
    # Unix epoch (10-digit integer at start of token)
    (re.compile(r'\b(1[0-9]{9})\b'),
     lambda m: datetime.fromtimestamp(int(m.group(1)), tz=timezone.utc)),
]


def parse_timestamp(token: str):
    for pattern, converter in _TS_PATTERNS:
        m = pattern.search(token)
        if m:
            try:
                return converter(m)
            except ValueError:
                continue
    return None


# ---------------------------------------------------------------------------
# Response-time normalisation (returns milliseconds as float)
# ---------------------------------------------------------------------------

def parse_response_time(token: str):
    """
    Handles: 142ms  0.142s  142  (bare number assumed ms)
    Returns float ms, or None if unparseable.
    Edge case: bare '0' is valid (0 ms), so we check is not None explicitly.
    """
    token = token.strip()
    if token.endswith('ms'):
        try:
            return float(token[:-2])
        except ValueError:
            return None
    if token.endswith('s'):
        try:
            return float(token[:-1]) * 1000
        except ValueError:
            return None
    try:
        v = float(token)
        # Sanity guard: suspiciously large bare number may not be ms
        return v
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Line parser
# ---------------------------------------------------------------------------

HTTP_METHODS = {'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'TRACE'}

_LOG_RE = re.compile(
    # Timestamp: either a single token OR a date+time pair (e.g. 2024/03/15 14:23:01)
    r'(?P<ts>\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}|\d{1,2}-[A-Za-z]{3}-\d{4} \d{2}:\d{2}:\d{2}|\S+)\s+'
    r'(?P<ip>\d{1,3}(?:\.\d{1,3}){3})\s+'  # IP address
    r'(?P<method>[A-Z]+)\s+'     # HTTP method
    r'(?P<path>\S+)\s+'          # path
    r'(?P<status>\d{3}|-)\s+'    # status code or '-'
    r'(?P<rt>\S+)'               # response time
)

_JSON_RE = re.compile(r'^\s*\{.*\}\s*$')


def parse_line(line: str):
    """
    Returns a dict with parsed fields, or None if the line is unsalvageable.
    Also returns a list of 'warnings' for soft anomalies.
    """
    line = line.strip()
    if not line:
        return None, 'blank'

    # JSON-formatted line (different log format bolted on)
    if _JSON_RE.match(line):
        try:
            obj = json.loads(line)
            # Try to extract standard fields from common JSON log keys
            ts_raw = obj.get('timestamp') or obj.get('time') or obj.get('ts') or ''
            ts = parse_timestamp(str(ts_raw)) if ts_raw else None
            method = obj.get('method', '').upper()
            path = obj.get('path') or obj.get('url') or obj.get('endpoint') or ''
            status_raw = obj.get('status') or obj.get('status_code') or obj.get('statusCode') or '-'
            try:
                status = int(status_raw)
            except (ValueError, TypeError):
                status = None
            rt_raw = obj.get('response_time') or obj.get('duration') or obj.get('latency') or ''
            rt = parse_response_time(str(rt_raw)) if rt_raw else None
            ip = obj.get('ip') or obj.get('remote_addr') or obj.get('client_ip') or ''
            return {
                'timestamp': ts,
                'ip': ip,
                'method': method if method in HTTP_METHODS else '',
                'path': path,
                'status': status,
                'response_time_ms': rt,
                'raw': line,
                'format': 'json',
                'warnings': [],
            }, None
        except json.JSONDecodeError:
            return None, 'malformed_json'

    # Standard (or near-standard) space-separated format
    m = _LOG_RE.match(line)
    if not m:
        # Partial / multi-line stack trace fragment — skip but count
        return None, 'malformed'

    warnings = []

    ts = parse_timestamp(m.group('ts'))
    if ts is None:
        warnings.append('unparseable_timestamp')

    method = m.group('method')
    if method not in HTTP_METHODS:
        warnings.append(f'unknown_method:{method}')

    status_raw = m.group('status')
    if status_raw == '-':
        status = None
        warnings.append('missing_status')
    else:
        status = int(status_raw)

    rt = parse_response_time(m.group('rt'))
    if rt is None:
        warnings.append('unparseable_response_time')

    return {
        'timestamp': ts,
        'ip': m.group('ip'),
        'method': method,
        'path': m.group('path'),
        'status': status,
        'response_time_ms': rt,
        'raw': line,
        'format': 'standard',
        'warnings': warnings,
    }, None


# ---------------------------------------------------------------------------
# Aggregation & analysis
# ---------------------------------------------------------------------------

def analyse(records):
    endpoint_times = defaultdict(list)   # path -> [ms, ...]
    status_counts = defaultdict(int)
    ip_counts = defaultdict(int)
    method_counts = defaultdict(int)
    error_paths = defaultdict(int)       # 4xx/5xx path -> count
    hourly = defaultdict(int)            # hour-str -> count

    for r in records:
        path = r['path']
        rt = r['response_time_ms']
        status = r['status']
        ip = r['ip']
        method = r['method']
        ts = r['timestamp']

        if rt is not None:
            endpoint_times[path].append(rt)
        if status is not None:
            status_counts[status] += 1
            if status >= 400:
                error_paths[path] += 1
        if ip:
            ip_counts[ip] += 1
        if method:
            method_counts[method] += 1
        if ts:
            hourly[ts.strftime('%Y-%m-%d %H:00')] += 1

    return endpoint_times, status_counts, ip_counts, method_counts, error_paths, hourly


def top_slowest(endpoint_times, n=10):
    """Return top-N endpoints by average response time."""
    avgs = {
        path: sum(times) / len(times)
        for path, times in endpoint_times.items()
        if times
    }
    return sorted(avgs.items(), key=lambda x: x[1], reverse=True)[:n]


def top_errored(error_paths, n=10):
    return sorted(error_paths.items(), key=lambda x: x[1], reverse=True)[:n]


def top_ips(ip_counts, n=10):
    return sorted(ip_counts.items(), key=lambda x: x[1], reverse=True)[:n]


# ---------------------------------------------------------------------------
# Report rendering
# ---------------------------------------------------------------------------

def render_text_report(
    total, parsed, skipped, skip_reasons, warning_count,
    records, endpoint_times, status_counts, ip_counts,
    method_counts, error_paths, hourly, top_n
):
    lines = []
    w = lines.append

    w("=" * 60)
    w("  LOG ANALYZER — SUMMARY REPORT")
    w("=" * 60)

    w(f"\n[ INGESTION ]")
    w(f"  Total lines read   : {total:,}")
    w(f"  Successfully parsed: {parsed:,}")
    w(f"  Skipped (bad lines): {skipped:,}")
    if skip_reasons:
        for reason, cnt in sorted(skip_reasons.items(), key=lambda x: -x[1]):
            w(f"    • {reason}: {cnt:,}")
    w(f"  Soft warnings      : {warning_count:,}")

    w(f"\n[ HTTP STATUS BREAKDOWN ]")
    for code in sorted(status_counts):
        label = {
            2: 'Success', 3: 'Redirect', 4: 'Client Error', 5: 'Server Error'
        }.get(code // 100, 'Other')
        w(f"  {code}  {label:<18} {status_counts[code]:>8,}")

    w(f"\n[ HTTP METHOD BREAKDOWN ]")
    for method, cnt in sorted(method_counts.items(), key=lambda x: -x[1]):
        w(f"  {method:<10} {cnt:>8,}")

    w(f"\n[ TOP {top_n} SLOWEST ENDPOINTS (avg ms) ]")
    for path, avg in top_slowest(endpoint_times, top_n):
        w(f"  {avg:>10.1f} ms   {path}")

    w(f"\n[ TOP {top_n} ERROR-PRONE PATHS (4xx/5xx count) ]")
    for path, cnt in top_errored(error_paths, top_n):
        w(f"  {cnt:>8,}   {path}")

    w(f"\n[ TOP {top_n} MOST ACTIVE IPs ]")
    for ip, cnt in top_ips(ip_counts, top_n):
        w(f"  {cnt:>8,}   {ip}")

    if hourly:
        w(f"\n[ TRAFFIC BY HOUR (top 10) ]")
        top_hours = sorted(hourly.items(), key=lambda x: -x[1])[:10]
        for hour, cnt in sorted(top_hours):
            bar = '█' * min(40, cnt // max(1, max(hourly.values()) // 40))
            w(f"  {hour}  {bar} {cnt:,}")

    w("\n" + "=" * 60)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='Analyse web server log files.')
    parser.add_argument('logfile', help='Path to the log file')
    parser.add_argument('--json', action='store_true', help='Output raw JSON instead of text report')
    parser.add_argument('--top', type=int, default=10, help='How many top-N entries to show (default 10)')
    args = parser.parse_args()

    path = Path(args.logfile)
    if not path.exists():
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(1)

    records = []
    total = 0
    skipped = 0
    skip_reasons = defaultdict(int)
    warning_count = 0

    with path.open('r', errors='replace') as fh:
        for line in fh:
            total += 1
            record, skip_reason = parse_line(line)
            if record is None:
                if skip_reason:
                    skipped += 1
                    skip_reasons[skip_reason] += 1
            else:
                warning_count += len(record['warnings'])
                records.append(record)

    parsed = len(records)

    endpoint_times, status_counts, ip_counts, method_counts, error_paths, hourly = analyse(records)

    if args.json:
        out = {
            'total_lines': total,
            'parsed': parsed,
            'skipped': skipped,
            'skip_reasons': dict(skip_reasons),
            'warning_count': warning_count,
            'status_counts': {str(k): v for k, v in status_counts.items()},
            'method_counts': dict(method_counts),
            'slowest_endpoints': top_slowest(endpoint_times, args.top),
            'error_paths': top_errored(error_paths, args.top),
            'top_ips': top_ips(ip_counts, args.top),
        }
        print(json.dumps(out, indent=2))
    else:
        report = render_text_report(
            total, parsed, skipped, skip_reasons, warning_count,
            records, endpoint_times, status_counts, ip_counts,
            method_counts, error_paths, hourly, args.top
        )
        print(report)


if __name__ == '__main__':
    main()
