# ANSWERS.md

## 1. How to Run

**Requirements:** Python 3.8+ (no third-party packages needed).

```bash
# Step 1 — generate a test log file
python scripts/generate_logs.py --lines 5000 --out test.log

# Step 2 — run the analyzer
python analyzer.py test.log

# Optional flags
python analyzer.py test.log --top 5       # show top-5 instead of top-10
python analyzer.py test.log --json        # machine-readable JSON output
```

Nothing to install beyond a standard Python installation.

---

## 2. Stack Choice

**Why Python, stdlib only?**

Python was the right choice for three reasons:

1. **Regex + string parsing is first-class.** The `re` module and string methods
   handle all the timestamp/format variation with little ceremony.
2. **No dependency footprint.** Using only the standard library means `python analyzer.py
   <file>` works on any machine with Python 3.8+, no virtual environment, no pip, no
   Docker required.
3. **Readable.** The parsing and aggregation logic is easy to follow and modify — the
   kind of script someone on-call actually wants to debug at 2 am.

**What would have been a worse choice?**

A compiled language like **Go or Rust** would give performance (important for very large
files) but the feedback loop for experimenting with regex patterns and output formatting
is much slower, and the resulting binary is harder to inspect or extend quickly.

A **JavaScript/Node.js** solution would also work, but async streaming of a local file
adds boilerplate that doesn't simplify anything here — the task is inherently sequential
(read line → parse → aggregate).

---

## 3. One Real Edge Case

**Edge case: bare numeric response-time token (`142` with no unit suffix)**

**File:** `analyzer.py`  
**Function:** `parse_response_time` (lines ~60–80)

The spec says response times appear as `142ms`, `0.142s`, or just `142` (a bare integer,
no unit). A naïve parser that only strips `ms` or `s` would return `None` for the bare
case, silently dropping that line from all latency statistics.

The function handles this explicitly:

```python
try:
    v = float(token)
    return v          # bare number — assumed milliseconds
except ValueError:
    return None
```

Without this, any log line with a bare numeric response time would contribute to the
`warning_count` (flagged as `unparseable_response_time`) and be excluded from the
"slowest endpoints" ranking, producing a misleadingly optimistic performance report.

A related guard: the function also handles `0` correctly — `if v is not None` elsewhere
in the code, not `if v`, so a genuine 0 ms response time is retained, not silently
dropped by a falsy check.

---

## 4. AI Usage

| Where | Tool | What I asked | What it gave |
|-------|------|--------------|--------------|
| Timestamp regex | Claude | "Give me a regex that matches ISO 8601 with optional Z or UTC offset" | Gave `(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:Z|[+-]\d{2}:\d{2})?` |
| JSON line detection | Claude | "How do I detect if a line is JSON without try/except first?" | Suggested a regex pre-check `^\s*\{.*\}\s*$` before attempting `json.loads` |
| Report formatting | Claude | "How should I format an ASCII bar chart in a terminal report?" | Suggested scaling bar width to `min(40, count // max_count * 40)` |

**One thing I changed:**

For the JSON-line detector, Claude's initial suggestion used `re.fullmatch(r'\{.*\}', line)`,
which would miss lines with leading whitespace and fail on log files where JSON entries are
indented. I changed it to `re.compile(r'^\s*\{.*\}\s*$')` with a compiled pattern so
it handles leading/trailing whitespace and is only compiled once (not on every line).

---

## 5. Honest Gap

**The weakest part: response-time unit assumption for bare numbers.**

When a line contains a bare number (e.g. `142`) with no unit suffix, the tool assumes
milliseconds. This is the most common convention, but if someone's log file uses
microseconds or seconds as the bare unit, all latency statistics will be off by 1000x
with no warning to the user.

**What I'd do with another day:**

1. Sample the first 500 parseable lines and look at the distribution of bare numbers
   alongside lines that do have explicit units. If the median bare number is < 10 and
   the median `ms`-suffixed number is > 50, the bare values are probably seconds, not
   milliseconds.
2. Emit a one-line warning at the top of the report: `"WARNING: bare response-time unit
   assumed to be ms. Verify with --rt-unit [ms|s|us]."` and add a `--rt-unit` flag to
   let the user override the assumption.
